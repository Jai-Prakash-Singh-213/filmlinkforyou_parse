import random
import  urllib2
import urllib2, feedparser
import logging 
from bs4 import BeautifulSoup
from lxml import html
import json
import time 
import os 

logging.basicConfig(level=logging.DEBUG, format='[%(levelname)s] (%(threadName)-10s) %(message)s')

file_pass_ip = ["SuperVIP94613:uEAT8I1jKY@46.148.30.106:8080",
                "SuperVIP94613:uEAT8I1jKY@188.190.124.45:8080",
                "SuperVIP94613:uEAT8I1jKY@78.24.221.42:8080",
                "SuperVIP94613:uEAT8I1jKY@91.220.202.51:8080",
                "SuperVIP94613:uEAT8I1jKY@91.220.202.25:8080",
                "SuperVIP94613:uEAT8I1jKY@193.106.31.208:8080",
                "SuperVIP94613:uEAT8I1jKY@62.109.28.78:8080",
                "SuperVIP94613:uEAT8I1jKY@92.63.105.129:8080",
                "SuperVIP94613:uEAT8I1jKY@195.226.220.169:8080",
                "SuperVIP94613:uEAT8I1jKY@46.148.31.127:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.89.168:8080",
                "SuperVIP94613:uEAT8I1jKY@91.220.202.111:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.88.158:8080",
                 "SuperVIP94613:uEAT8I1jKY@62.109.6.58:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.89.52:8080",
                "SuperVIP94613:uEAT8I1jKY@193.106.31.28:8080",
                "SuperVIP94613:uEAT8I1jKY@91.220.202.188:8080",
                "SuperVIP94613:uEAT8I1jKY@91.217.90.87:8080",
                "SuperVIP94613:uEAT8I1jKY@193.106.31.125:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.89.167:8080",
                "SuperVIP94613:uEAT8I1jKY@62.122.76.43:8080",
                "SuperVIP94613:uEAT8I1jKY@62.122.76.54:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.89.56:8080",
                "SuperVIP94613:uEAT8I1jKY@46.148.31.149:8080",
                "SuperVIP94613:uEAT8I1jKY@62.122.77.77:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.89.171:8080",
                "SuperVIP94613:uEAT8I1jKY@91.220.202.29:8080",
                "SuperVIP94613:uEAT8I1jKY@193.106.31.64:8080",
                "SuperVIP94613:uEAT8I1jKY@62.122.77.93:8080",
                "SuperVIP94613:uEAT8I1jKY@62.122.77.16:8080",
                "SuperVIP94613:uEAT8I1jKY@91.217.90.95:8080",  
                 "SuperVIP94613:uEAT8I1jKY@195.74.89.198:8080", 
                "SuperVIP94613:uEAT8I1jKY@195.74.88.190:8080",
                "SuperVIP94613:uEAT8I1jKY@195.74.88.56:8080",
                ] 



def main(url):
    while True:
        try:
            pass_ip = random.choice(file_pass_ip).strip()
            logging.debug(pass_ip)
            proxy = urllib2.ProxyHandler({'http': 'http://'+pass_ip})
            auth = urllib2.HTTPBasicAuthHandler()
            opener = urllib2.build_opener(proxy, auth, urllib2.HTTPHandler)
            urllib2.install_opener(opener)
            return proxy
        except:
            pass



def supermain(tvs, url):
    proxy = main(url)

    #filename = "%s/%s%s" %(os.getcwd(), tvs, time.strftime("%d%m%Y"))
    filename = "/home/user1/gdtayoutube/%s%s" %(tvs, time.strftime("%d%m%Y"))

    f = open(filename, "w+")

    d = feedparser.parse(url,   handlers = [proxy])
    
    gdatajson = []    

    for post in d.entries:
        summary_detail = str(post.summary_detail["value"])
        soup = BeautifulSoup(summary_detail, "html.parser")
        img_link = soup.find("img").get("src")
        gdatajson.append({"title":str(post.title)[:str(post.title).find("-")], 
                          "link": str(post.link)[:str(post.link).find("&")], 
                          "data_updated":str(post.updated), 
                          "img_link":str(img_link)})

    if  len(gdatajson) == 0:
        supermain(tvs, url)

    else:
        filename = "%s/%s%s" %(os.getcwd(), tvs, time.strftime("%d%m%Y"))

        valu_dict = {"value":gdatajson}
        json_encoded = json.dumps(valu_dict)

        f.write(str(json_encoded))
        f.close()      

        print valu_dict


def sub_supermain():
    tvs_lnk = {"strpls":"http://gdata.youtube.com/feeds/base/users/starplus/uploads?v=2&orderby=updated&alt=rss&client=ytapi-youtube-rss-redirect",             "lifeok":"http://gdata.youtube.com/feeds/base/users/lifeok/uploads?client=ytapi-youtube-rss-redirect&alt=rss&orderby=updated&v=2",               "channlv":"http://gdata.youtube.com/feeds/base/users/channelvindia/uploads?orderby=updated&alt=rss&client=ytapi-youtube-rss-redirect&v=2",       "sony":"http://gdata.youtube.com/feeds/base/users/setindia/uploads?v=2&orderby=updated&client=ytapi-youtube-rss-redirect&alt=rss",
               "zeetv":"http://gdata.youtube.com/feeds/base/users/zeetv/uploads?v=2&alt=rss&orderby=updated&client=ytapi-youtube-rss-redirect"}

    for tvs, link in tvs_lnk.items():
        supermain(tvs, link)
    

if __name__=="__main__":
    sub_supermain()
