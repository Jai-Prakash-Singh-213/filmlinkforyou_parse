import random
import  urllib2
import urllib2, feedparser
import logging 
from bs4 import BeautifulSoup
from lxml import html
import json
import time 

logging.basicConfig(level=logging.DEBUG, format='[%(levelname)s] (%(threadName)-10s) %(message)s')




def main(url):
    f = open("/home/desktop/proxy_http_auth.txt")
    file_pass_ip = f.read().strip().split('\n')
    f.close()

    while True:
        try:
            pass_ip = random.choice(file_pass_ip).strip()
            logging.debug(pass_ip)
            proxy = urllib2.ProxyHandler({'http': 'http://'+pass_ip})
            auth = urllib2.HTTPBasicAuthHandler()
            opener = urllib2.build_opener(proxy, auth, urllib2.HTTPHandler)
            urllib2.install_opener(opener)
            return proxy
        except:
            pass



def supermain():
    url = "http://gdata.youtube.com/feeds/base/users/zeetv/uploads?v=2&alt=rss&orderby=updated&client=ytapi-youtube-rss-redirect"
    proxy = main(url)

    filename = "/home/desktop/gdtayoutube/gdatayoutube%s" %(time.strftime("%d%m%Y"))

    f = open(filename, "w+")

    d = feedparser.parse(url,   handlers = [proxy])
    
    gdatajson = []    

    for post in d.entries:
        summary_detail = str(post.summary_detail["value"])
        soup = BeautifulSoup(summary_detail, "html.parser")
        img_link = soup.find("img").get("src")
        gdatajson.append({"title":str(post.title)[:str(post.title).find("-")], 
                          "link": str(post.link)[:str(post.link).find("&")], 
                          "data_updated":str(post.updated), 
                          "img_link":str(img_link)})
    print post 
    valu_dict = {"value":gdatajson}
    json_encoded = json.dumps(valu_dict)
    print valu_dict

    f.write(str(json_encoded))
    f.close()        



if __name__=="__main__":
    supermain()
