import rss_tv_show




def  main():
    rss_tv_show.sub_supermain()



if __name__=="__main__":
    main()
